@extends('frontend.layouts.app')

@push('css')
    <style>
        #button{
            position: absolute;
            right: 20%;
            bottom: 10%;
            background-color: red;
        }
        body{
          color:#fff
        }
        .right_conatct_social_icon{
             background: linear-gradient(to top right, #1325e8 -5%, #8f10b7 100%);
        }
        .contact_us{
            background-color: #f1f1f1;
            padding: 0px 0px;
        }
        .contact .contact_field a:hover{
            font-size: inherit !important;
        }
        
        .contact_inner{
            background-color: #fff;
            position: relative;
            box-shadow: 20px 22px 44px #cccc;
            border-radius: 25px;
        }
        .contact_field{
            padding: 60px 340px 90px 110px;
        }
        .right_conatct_social_icon{
            height: 100%;
        }
        
        .contact_field h3{
           color: #000;
            font-size: 40px;
            letter-spacing: 1px;
            font-weight: 600;
            margin-bottom: 10px
        }
        .contact_field p{
            color: #000;
            font-size: 13px;
            font-weight: 400;
            letter-spacing: 1px;
            margin-bottom: 35px;
        }
        .contact_field .form-control{
            border-radius: 0px;
            border: none;
            border-bottom: 1px solid #ccc;
        }
        .contact_field .form-control:focus{
            box-shadow: none;
            outline: none;
            border-bottom: 2px solid #1325e8;
        }
        .contact_field .form-control::placeholder{
            font-size: 13px;
            letter-spacing: 1px;
        }
        
        .contact_info_sec {
            position: absolute;
            background-color: #2d2d2d;
            right: 1px;
            top: 18%;
            height: auto;
            width: 380px;
            padding: 40px;
            border-radius: 25px 0 0 25px;
        }
        .contact_info_sec h4{
            letter-spacing: 1px;
            padding-bottom: 15px;
        }
        
        .info_single{
            margin: 20px 0px;
        }
        .info_single i{
            margin-right: 15px;
        }
        .info_single span{
            font-size: 20px;
            letter-spacing: 1px;
        }
        
        contact_form_submit {
            background: linear-gradient(to top right, #1325e8 -5%, #8f10b7 100%);
            border: none;
            color: #fff;
            padding: 10px 15px;
            width: 100%;
            margin-top: 25px;
            border-radius: 35px;
            cursor: pointer;
            font-size: 14px;
            letter-spacing: 2px;
        }
        .socil_item_inner li{
            list-style: none;
        }
        .socil_item_inner li a{
            color: #fff;
            margin: 0px 15px;
            font-size: 14px;
        }
        .socil_item_inner{
            padding-bottom: 10px;
        }
        
        .map_sec{
            padding: 100px 0px 0;
        }
        .map_inner h4, .map_inner p{
            color: #000;
            text-align: center;
            padding: 10px 0;
            color: #fff;
        }
        .map_inner p{
            font-size: 13px;
        }
        .map_bind{
           margin-top: 50px;
            border-radius: 30px;
            overflow: hidden;
        }
        
        @media (max-width: 991px){
            .contact_field{
                width: 100% !important;
                display: block;
            }
            .contact_info_sec{
                width: 100% !important;
                display: block;
            }
            .contact_info_sec{
                position: relative!important;
            }
            .contact_field {
                padding: 60px 20px 90px;
            }
        }
         
    </style>
@endpush

@section('content')
<section id="slider">
    <div class="heading"></div>
    <div class="swiper-container" data-aos="zoom-out-up" data-aos-duration="1500">
       <div class="swiper-wrapper">
      <div class="swiper-slide">
        <div class="container-general">
        <div class="gallery-wrap wrap-effect-2">
            @foreach($banners as $key=>$banner)
                <div class="item" style="background-image: url({{asset('/storage/'.$banner['image'])}})">
                        
                </div>
            @endforeach
        </div>
        </div>
    </div>
</div>
    </div>
</section>
<section id="service">
        <div class="services content">
            <div class="container-fluid">
                <div class="service-title d-flex justify-content-between">
                    <div class="service-title-header">
                        <h2 style="color: #fff;">Services</h2>
                    </div>
                </div>
                
                <div class="row" data-aos="zoom-in-down" data-aos-duration="1500">
                    @foreach($services as $service)
                    <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 mb-3">
                        <div class="box p-5">
                            <img src="{{asset('storage/images/admin/services/'.$service->image)}}" alt="Services Image" style="width: 65px; text-align: center">
                            
                            <h4 class="pt-4">{{$service->name}}</h4>
                            <p>{{$service->details}}</p>
                            <a class="readmore" href="#contact"><span>Read More</span></a>
                        </div>
                    </div>
                    @endforeach
                    
                </div>
            </div>
        </div>
    </section>
    <section id="about-us" style='overflow: hidden;'>
    <div class="about content">
        <div class="upper">
          <div class="logo">
            <div class="image">
              <div class="camp">
                <img src="{{asset('assets/frontend/uploads/24-7-mobile.gif')}}" alt="About Image" id="tent" />
              </div>
            </div>
          </div>
          <div class="info">
            <h1 class="mb-3">ABOUT <span style="color: rgb(241, 148, 8);">ATL</span></h1>
            <p>{{$about->details}}</p>
          </div>
        </div>
      </div>
    </section>
    <section class="section gray-bg mt-5" id="blog">
    <div class="container-fluid content">
        <div class="row justify-content-center">
            <div class="col-lg-7 text-center">
                <div class="section-title mb-4">
                    <h2 style="color: #000; font: 2 rem; font-weight: 600;">OUR PRODUCTS</h2>
                </div>
            </div>
        </div>
        <div class="row">
            @foreach ($products as $product)
            <div class="col-md-6 col-lg-4 col-xl-3">
                <div class="blog-grid">
                    <div class="blog-img">
                        <div class="date">AVAILABLE</div>
                        <a href="{{url('/single_product',$product['id'])}}">
                            <img src="{{asset('storage/images/admin/product/'.$product['image'])}}" title="" alt="Product Image">
                        </a>
                    </div>
                    <div class="blog-info" style="height: 230px">
                        <h5><a href="#contact">{{$product['name']}}</a></h5>
                        <p>{{Str::limit($product['details'],70)}}</p>
                        <div class="btn-bar">
                            <a href="#contact" class="px-btn-arrow">
                                <span>Enquiry Now</span>
                                <i class="arrow"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        <a class="moreless-button" style="color:blue; text-align: end;" href="#blog">View all</a>
    </div>
</section>
<section id="website">
    <div class="packages content">
        <div class="container-fluid">
            <div class="service-title d-flex justify-content-between">
                <div class="service-title-header">
                    <h2 style="color: #fff;">WEBSITE DESIGN AND DEVELOPMENT PACKAGES</h2>
                </div>
            </div>
            <div id="generic_price_table">   
                <section>
                    <div class="container">
                        <div class="row" id="show-more-item">
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>Portfolio</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                    <ul>
                                        <li> 2-3 pages.</li>
                                        <li> Dynamic and .</li>
                                        <li><span></span>Lifetime support</li>
                                        <li><span></span>Free Domain + Hosting</li>
                                        <li><span></span> Cpanel free SSL</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>Startup</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                   <ul>
                                        <li> 10+ pages with slider</li>
                                        <li> Dynamic content.</li>
                                        <li><span></span>Lifetime support</li>
                                        <li><span></span>Free Domain + Hosting</li>
                                        <li><span></span> Cpanel free SSL</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>Enterprise</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                   <ul>
                                        <li> 15+ pages with slider</li>
                                        <li> Dynamic content & design.</li>
                                        <li><span></span>Lifetime support</li>
                                        <li><span></span>Free Domain + Hosting</li>
                                        <li><span></span> 24/7 Customer support</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>Multitasking</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                     <ul>
                                        <li> Dynamic page creation</li>
                                        <li> Slution system</li>
                                        <li><span></span>Lifetime support</li>
                                        <li><span></span>Free Domain + Hosting</li>
                                        <li><span></span> 24/7 Customer support</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </section> 
            </div>
        </div>
    </div>
</section>
<section id="social">
    <div class="packages content">
        <div class="container-fluid">
            <div class="service-title d-flex justify-content-between">
                <div class="service-title-header">
                    <h2 style="color: #fff;">SOCIAL MEDIA MANAGEMENTS </h2>
                </div>
            </div>
            <div id="generic_price_table">   
                <section>
                    <div class="container ">
                        <div class="row m-auto" id="show-more-item">
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>package 1</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                    <ul>
                                        <li><span>10</span> Posts in Social Media</li>
                                        <li><span>10</span> Promotion Banner</li>
                                        <li><span>+</span> Bonus post on festival</li>
                                        <li><span>2</span> Adds Design</li>
                                        <li><span>24/7</span> Support</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>package 2</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                    <ul>
                                        <li><span>15</span> Posts in Social Media</li>
                                        <li><span>15</span> Promotion Banner</li>
                                        <li><span>++</span> Bonus post on festival</li>
                                        <li><span>2</span> Adds Design</li>
                                        <li><span>24/7</span> Support</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>package 3</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                    <ul>
                                        <li><span>20</span> Posts in Social Media</li>
                                        <li><span>20</span> Promotion Banner</li>
                                        <li><span>2x</span> Bonus post on festival</li>
                                        <li><span>5</span> Adds Design</li>
                                        <li><span>24/7</span> 1 customer support</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-6 col-lg-6 col-xl-3" style="color: #21256B;">
                            <div class="generic_content clearfix">
                                <div class="generic_head_price clearfix">
                                    <div class="generic_head_content clearfix">
                                        <div class="head_bg"></div>
                                        <div class="head">
                                            <span>package 4</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="generic_feature_list">
                                    <ul>
                                        <li> Unlimited Posts</li>
                                        <li> Unlimited Promotion Banner</li>
                                        <li> Unlimited Bonus post</li>
                                        <li> Unlimited Adds Design</li>
                                        <li> 24/7 Customer support</li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn clearfix">
                                    <a class="" href="#contact">Enroll Now</a>
                                </div>
                            </div>
                          </div>
                          
                        </div>
                    </div>
                </section> 
            </div>
        </div>
    </div>
</section>
<section id="news">
    <section class="home-blog bg-sand">
        <div class="container-fluid content">
            <div class="row justify-content-md-center">
                <div class="col-xl-5 col-lg- col-md-8">
                    <div class="service-title section-title text-center title-ex1">
                        <h2 class="news_title">NEWS & BLOG</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                @foreach ($newses as $news)
                <div class="col-md-6 col-lg-6 col-xl-4">
                    <div class="media blog-media">
                       
                        <a href="{{url('single_news',$news['id'])}}"><img class="d-flex" src="{{asset('storage/images/admin/news/'.$news['image'])}}" alt="News Image"></a>
                         
                      <div class="media-body">
                        <a href=""><h5 class="mt-0">{{$news['name']}}</h5></a>
                        {{Str::limit($news['details']),40}}
                        <a href="{{url('single_news',$news['id'])}}" class="post-link">Read More->></a>
                      </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
</section>

 <section class="contact_us" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="contact_inner">
                        <div class="row">
                            <div class="col-md-10">
                                <div class="contact_form_inner">
                                    <div class="contact_field">
                                        <div class="customer_service">
                                            <img src="{{asset('assets/frontend/5124556.jpg')}}" alt="Contact Image" width="100%">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div class="contact_info_sec">
                            <h4>Contact Info</h4>
                            <div class="d-flex info_single align-items-center gap-3">
                                <i class="fas fa-headset"></i>
                                <span style="padding-left: 15px">+88 01973198574</span>
                            </div>
                            <div class="d-flex info_single align-items-center gap-3">
                                <i class="fas fa-headset"></i>
                                <span style="padding-left: 15px">+88 09638553344</span>
                            </div>
                            <div class="d-flex info_single align-items-center gap-3">
                                <i class="fas fa-envelope-open-text"></i>
                                <span style="padding-left: 15px">connect@ayaantec.com</span>
                            </div>
                            <div class="d-flex info_single align-items-center gap-3">
                                <i class="fas fa-map-marked-alt"></i>
                                <span style="padding-left: 15px">House:24, Road:14, Niketon Gulshan-1, Dhaka Bangladesh 1219.</span>
                            </div>
            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="map_sec">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="map_inner">
                    <h4>Find Us on Google Map</h4>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.3049896715934!2d90.40464421498177!3d23.772151384578702!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7d1db46ec61%3A0x45203ae6068e299b!2sAyaan%20Tech%20Limited!5e0!3m2!1sen!2sbd!4v1673430841120!5m2!1sen!2sbd" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="reviews_box">
                         <h4>What clients says</h4>
                         <script defer async src='https://cdn.trustindex.io/loader.js?d617fa7113b66813cf76a267892'></script>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </section>


 <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>


@stop
@push('js')
   
@endpush